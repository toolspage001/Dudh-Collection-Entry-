export type RateType = 'FIX' | 'FAT';

export interface Entry {
  id: string;
  customerId: string;
  date: string; // ISO string
  shift: 'Morning' | 'Evening';
  milkType: 'Cow' | 'Buffalo';
  rateType: RateType;
  weight: number;
  fat?: number; // Only for FAT rate type
  ratePerLtr: number;
  totalAmount: number;
  timestamp: number;
}

export interface Customer {
  id: string;
  name: string;
  mobile: string;
  defaultRateType: RateType;
}

export interface UserProfile {
  dairyName: string;
  ownerName: string;
  mobile: string;
}

// Global App State
export interface AppState {
  view: 'HOME' | 'CUSTOMER_DETAIL' | 'PROFILE';
  selectedCustomerId: string | null;
}