import React from 'react';

const Logo: React.FC<{ className?: string }> = ({ className = "w-12 h-12" }) => {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Background Rounded Square */}
      <rect width="100" height="100" rx="20" fill="#0EA5E9" />
      
      {/* Milk Can Body */}
      <path d="M30 35H70V80C70 85 66 88 60 88H40C34 88 30 85 30 80V35Z" fill="#E2E8F0" />
      
      {/* Milk Can Neck/Lid area */}
      <rect x="35" y="25" width="30" height="10" fill="#E2E8F0" />
      <rect x="28" y="22" width="44" height="6" rx="2" fill="#E2E8F0" />
      
      {/* Handles */}
      <path d="M25 40C22 40 20 45 25 50" stroke="#E2E8F0" strokeWidth="4" strokeLinecap="round" />
      <path d="M75 40C78 40 80 45 75 50" stroke="#E2E8F0" strokeWidth="4" strokeLinecap="round" />

      {/* The Big Drop (Foreground) */}
      <path d="M50 30C50 30 65 55 65 68C65 76.2843 58.2843 83 50 83C41.7157 83 35 76.2843 35 68C35 55 50 30 50 30Z" fill="white" stroke="#0EA5E9" strokeWidth="2"/>
      
      {/* Drop Reflection */}
      <path d="M42 65C42 62 44 58 46 56" stroke="#0EA5E9" strokeWidth="2" strokeLinecap="round" opacity="0.5" />
    </svg>
  );
};

export default Logo;