import React, { useState, useEffect, useMemo } from 'react';
import { Customer, Entry, RateType } from '../types';
import { getCustomers, saveEntry, getEntries, deleteEntry } from '../services/storageUtils';
import { analyzeCustomerData } from '../services/geminiService';
import { 
  ArrowLeft, 
  Calendar, 
  Droplet, 
  IndianRupee, 
  History, 
  PlusCircle, 
  Download, 
  Sparkles,
  Trash2
} from 'lucide-react';

interface Props {
  customerId: string;
  onBack: () => void;
}

const CustomerDetail: React.FC<Props> = ({ customerId, onBack }) => {
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [activeTab, setActiveTab] = useState<'ENTRY' | 'REPORT'>('ENTRY');
  
  // Entry Form State
  const [entryDate, setEntryDate] = useState(new Date().toISOString().split('T')[0]);
  const [shift, setShift] = useState<'Morning' | 'Evening'>('Morning');
  const [milkType, setMilkType] = useState<'Cow' | 'Buffalo'>('Buffalo');
  const [rateType, setRateType] = useState<RateType>('FIX');
  const [weight, setWeight] = useState('');
  const [fat, setFat] = useState('');
  const [rate, setRate] = useState(''); // Rate per Fat or Fix Rate
  const [entries, setEntries] = useState<Entry[]>([]);
  
  // Report State
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(1); // First day of current month
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  
  // AI State
  const [aiInsight, setAiInsight] = useState<string>("");
  const [loadingAi, setLoadingAi] = useState(false);

  useEffect(() => {
    const allCustomers = getCustomers();
    const found = allCustomers.find(c => c.id === customerId);
    if (found) {
      setCustomer(found);
      setRateType(found.defaultRateType);
    }
    loadEntries();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customerId]);

  const loadEntries = () => {
    const loadedEntries = getEntries(customerId);
    // Sort by date desc
    loadedEntries.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    setEntries(loadedEntries);
  };

  const calculateTotal = () => {
    const w = parseFloat(weight) || 0;
    const r = parseFloat(rate) || 0;
    const f = parseFloat(fat) || 0;

    if (rateType === 'FIX') {
      return w * r;
    } else {
      // FAT Logic: Rate is usually Per Fat Unit (e.g. 7 Rs per fat) or Fixed Chart
      // Simple logic: Price/Ltr = Fat * Rate_Per_Fat
      const pricePerLtr = f * r;
      return w * pricePerLtr;
    }
  };

  const handleSaveEntry = () => {
    if (!customer || !weight || !rate) return;
    
    const w = parseFloat(weight);
    const r = parseFloat(rate);
    const f = rateType === 'FAT' ? parseFloat(fat) : undefined;
    
    // Validate
    if (rateType === 'FAT' && !f) {
      alert("Please enter Fat");
      return;
    }

    const calculatedTotal = calculateTotal();
    const pricePerLtr = rateType === 'FIX' ? r : (f! * r);

    const newEntry: Entry = {
      id: Date.now().toString(),
      customerId: customer.id,
      date: entryDate,
      shift,
      milkType,
      rateType,
      weight: w,
      fat: f,
      ratePerLtr: pricePerLtr, // Store effective rate per ltr
      totalAmount: calculatedTotal,
      timestamp: Date.now()
    };

    saveEntry(newEntry);
    loadEntries();
    
    // Reset form mostly, keep date/shift mostly same for speed
    setWeight('');
    setFat('');
    // Keep rate as it usually stays same
    alert(`Entry Saved! Total: ₹${calculatedTotal.toFixed(2)}`);
  };

  const handleDeleteEntry = (id: string) => {
    if(window.confirm("Are you sure you want to delete this entry?")) {
        deleteEntry(id);
        loadEntries();
    }
  }

  const handleAiAnalysis = async () => {
    if (!customer) return;
    setLoadingAi(true);
    setAiInsight("");
    const insight = await analyzeCustomerData(customer, entries);
    setAiInsight(insight || "No data available.");
    setLoadingAi(false);
  };

  // Filtered entries for report
  const reportEntries = useMemo(() => {
    return entries.filter(e => e.date >= startDate && e.date <= endDate);
  }, [entries, startDate, endDate]);

  const reportTotalMilk = reportEntries.reduce((sum, e) => sum + e.weight, 0);
  const reportTotalAmount = reportEntries.reduce((sum, e) => sum + e.totalAmount, 0);

  const handlePrint = () => {
    window.print();
  };

  if (!customer) return <div>Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Navbar */}
      <div className="bg-blue-600 text-white p-4 sticky top-0 z-20 flex items-center gap-3 shadow-md no-print">
        <button onClick={onBack} className="p-1 hover:bg-blue-700 rounded-full">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div>
          <h1 className="font-bold text-lg">{customer.name}</h1>
          <p className="text-xs text-blue-100">{customer.mobile}</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white flex border-b no-print">
        <button 
          onClick={() => setActiveTab('ENTRY')}
          className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 ${activeTab === 'ENTRY' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
        >
          <PlusCircle className="w-4 h-4" /> New Entry
        </button>
        <button 
          onClick={() => setActiveTab('REPORT')}
          className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 ${activeTab === 'REPORT' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
        >
          <History className="w-4 h-4" /> History & PDF
        </button>
      </div>

      <div className="flex-1 overflow-y-auto no-print">
        {activeTab === 'ENTRY' ? (
          <div className="p-4 space-y-6 max-w-lg mx-auto">
            {/* Date & Shift Section */}
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 space-y-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="text-xs font-semibold text-gray-500 uppercase">Date</label>
                  <input 
                    type="date" 
                    value={entryDate} 
                    onChange={e => setEntryDate(e.target.value)}
                    className="w-full mt-1 p-2 border rounded-lg bg-gray-50 font-medium" 
                  />
                </div>
                <div className="flex-1">
                   <label className="text-xs font-semibold text-gray-500 uppercase">Shift</label>
                   <select 
                    value={shift} 
                    onChange={e => setShift(e.target.value as any)}
                    className="w-full mt-1 p-2 border rounded-lg bg-gray-50 font-medium"
                   >
                     <option value="Morning">Morning</option>
                     <option value="Evening">Evening</option>
                   </select>
                </div>
              </div>
            </div>

            {/* Milk Details Section */}
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 space-y-4">
               {/* Rate Type Switch */}
               <div className="flex bg-gray-100 p-1 rounded-lg mb-2">
                 <button 
                   onClick={() => setRateType('FIX')}
                   className={`flex-1 py-1.5 rounded-md text-sm font-medium transition-all ${rateType === 'FIX' ? 'bg-white shadow text-blue-700' : 'text-gray-500'}`}
                 >
                   Fix Rate
                 </button>
                 <button 
                   onClick={() => setRateType('FAT')}
                   className={`flex-1 py-1.5 rounded-md text-sm font-medium transition-all ${rateType === 'FAT' ? 'bg-white shadow text-blue-700' : 'text-gray-500'}`}
                 >
                   Fat Rate
                 </button>
               </div>

               {/* Weight Input */}
               <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase flex items-center gap-1">
                    <Droplet className="w-3 h-3" /> Weight (Liters)
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    placeholder="0.0" 
                    value={weight}
                    onChange={e => setWeight(e.target.value)}
                    className="w-full mt-1 p-3 text-xl font-bold border border-blue-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" 
                  />
               </div>

               {/* Fat Input (Conditional) */}
               {rateType === 'FAT' && (
                 <div>
                    <label className="text-xs font-semibold text-gray-500 uppercase">Fat Content</label>
                    <input 
                      type="number" 
                      step="0.1"
                      placeholder="e.g. 6.5" 
                      value={fat}
                      onChange={e => setFat(e.target.value)}
                      className="w-full mt-1 p-3 text-lg font-medium border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" 
                    />
                 </div>
               )}

               {/* Rate Input */}
               <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase">
                    {rateType === 'FIX' ? 'Rate per Liter (₹)' : 'Rate per Fat (₹)'}
                  </label>
                  <input 
                    type="number" 
                    step="0.1"
                    placeholder="0.00" 
                    value={rate}
                    onChange={e => setRate(e.target.value)}
                    className="w-full mt-1 p-3 text-lg font-medium border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" 
                  />
                  {rateType === 'FAT' && weight && fat && rate && (
                     <p className="text-right text-xs text-gray-500 mt-1">
                       Calc Rate: ₹{(parseFloat(fat) * parseFloat(rate)).toFixed(2)} / Ltr
                     </p>
                  )}
               </div>

               {/* Total Preview */}
               <div className="bg-blue-50 p-4 rounded-lg flex justify-between items-center border border-blue-100">
                  <span className="text-blue-800 font-medium">Total Amount</span>
                  <span className="text-2xl font-bold text-blue-700">₹{calculateTotal().toFixed(2)}</span>
               </div>
            </div>

            <button 
              onClick={handleSaveEntry}
              className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:bg-blue-700 active:scale-95 transition-all"
            >
              Save Entry
            </button>

             {/* Recent 3 entries preview */}
             <div className="mt-8">
               <h3 className="text-sm font-bold text-gray-500 mb-2 uppercase">Recent Entries</h3>
               <div className="space-y-2">
                 {entries.slice(0, 3).map(entry => (
                   <div key={entry.id} className="bg-white p-3 rounded-lg border border-gray-100 flex justify-between items-center text-sm">
                      <div>
                        <span className="font-medium">{new Date(entry.date).toLocaleDateString()}</span>
                        <span className="text-gray-400 mx-1">•</span>
                        <span className="text-gray-500">{entry.shift}</span>
                      </div>
                      <div className="font-bold">₹{entry.totalAmount.toFixed(0)}</div>
                   </div>
                 ))}
               </div>
             </div>
          </div>
        ) : (
          <div className="p-4 space-y-4 max-w-4xl mx-auto">
            {/* Filters */}
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-gray-500 font-bold block mb-1">From</label>
                <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-full p-2 border rounded-md text-sm" />
              </div>
              <div>
                <label className="text-xs text-gray-500 font-bold block mb-1">To</label>
                <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-full p-2 border rounded-md text-sm" />
              </div>
            </div>

            {/* AI Analysis */}
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-4 rounded-xl border border-indigo-100">
               <div className="flex justify-between items-start mb-2">
                 <h3 className="text-indigo-900 font-bold flex items-center gap-2">
                   <Sparkles className="w-4 h-4 text-indigo-600" /> Smart Insights
                 </h3>
                 <button 
                  onClick={handleAiAnalysis}
                  disabled={loadingAi}
                  className="text-xs bg-white text-indigo-600 px-3 py-1 rounded-full border border-indigo-200 hover:bg-indigo-50"
                 >
                   {loadingAi ? 'Analyzing...' : 'Analyze Now'}
                 </button>
               </div>
               {aiInsight ? (
                 <p className="text-sm text-indigo-800 leading-relaxed italic">"{aiInsight}"</p>
               ) : (
                 <p className="text-xs text-indigo-400">Click Analyze to get insights on this customer's production.</p>
               )}
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-green-50 p-4 rounded-xl border border-green-100">
                 <p className="text-xs text-green-600 font-bold uppercase">Total Milk</p>
                 <p className="text-2xl font-bold text-green-800">{reportTotalMilk.toFixed(1)} <span className="text-sm font-normal">Ltr</span></p>
              </div>
              <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
                 <p className="text-xs text-blue-600 font-bold uppercase">Total Amount</p>
                 <p className="text-2xl font-bold text-blue-800">₹{reportTotalAmount.toFixed(0)}</p>
              </div>
            </div>

            {/* Action Buttons */}
            <button 
              onClick={handlePrint}
              className="w-full flex items-center justify-center gap-2 bg-gray-800 text-white py-3 rounded-xl font-medium hover:bg-gray-900"
            >
              <Download className="w-4 h-4" /> Download PDF / Print
            </button>

            {/* List for Mobile View */}
            <div className="space-y-3 pb-20">
              {reportEntries.map(entry => (
                <div key={entry.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 relative group">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="font-bold text-gray-800">{new Date(entry.date).toLocaleDateString()}</p>
                      <p className="text-xs text-gray-500">{entry.shift} • {entry.milkType}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-blue-600">₹{entry.totalAmount.toFixed(2)}</p>
                      <p className="text-xs text-gray-400">@{entry.ratePerLtr.toFixed(2)}/L</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-sm border-t pt-2 mt-2">
                     <span className="bg-gray-100 px-2 py-1 rounded text-gray-600 font-medium">
                       {entry.weight} Ltr
                     </span>
                     {entry.fat && (
                       <span className="text-gray-500">Fat: {entry.fat}</span>
                     )}
                     <button onClick={() => handleDeleteEntry(entry.id)} className="text-red-400 hover:text-red-600 p-1">
                        <Trash2 className="w-4 h-4" />
                     </button>
                  </div>
                </div>
              ))}
              {reportEntries.length === 0 && <p className="text-center text-gray-400 py-10">No entries in this range.</p>}
            </div>
          </div>
        )}
      </div>

      {/* PRINT VIEW (Hidden normally, visible only in print) */}
      <div className="print-only fixed inset-0 bg-white z-[100] p-8">
         <div className="text-center mb-8 border-b pb-4">
           <h1 className="text-3xl font-bold text-gray-800">DairyBook Collection Report</h1>
           <p className="text-gray-600 mt-2">Customer: <span className="font-bold">{customer.name}</span></p>
           <p className="text-gray-500 text-sm">Period: {startDate} to {endDate}</p>
         </div>

         <table className="w-full text-left border-collapse">
           <thead>
             <tr className="border-b-2 border-gray-300">
               <th className="py-2 text-sm">Date</th>
               <th className="py-2 text-sm">Shift</th>
               <th className="py-2 text-sm text-right">Fat</th>
               <th className="py-2 text-sm text-right">Liters</th>
               <th className="py-2 text-sm text-right">Rate</th>
               <th className="py-2 text-sm text-right">Total</th>
             </tr>
           </thead>
           <tbody>
             {reportEntries.map(e => (
               <tr key={e.id} className="border-b border-gray-100">
                 <td className="py-2 text-sm">{e.date}</td>
                 <td className="py-2 text-sm">{e.shift.charAt(0)}</td>
                 <td className="py-2 text-sm text-right">{e.fat || '-'}</td>
                 <td className="py-2 text-sm text-right">{e.weight}</td>
                 <td className="py-2 text-sm text-right">{e.ratePerLtr.toFixed(2)}</td>
                 <td className="py-2 text-sm text-right font-bold">₹{e.totalAmount.toFixed(2)}</td>
               </tr>
             ))}
           </tbody>
           <tfoot>
             <tr className="border-t-2 border-black">
               <td className="py-4 font-bold">Total</td>
               <td></td>
               <td></td>
               <td className="py-4 text-right font-bold">{reportTotalMilk.toFixed(1)} L</td>
               <td></td>
               <td className="py-4 text-right font-bold text-lg">₹{reportTotalAmount.toFixed(2)}</td>
             </tr>
           </tfoot>
         </table>

         <div className="mt-12 text-center text-xs text-gray-400">
           Generated by DairyBook App
         </div>
      </div>
    </div>
  );
};

export default CustomerDetail;
