import React, { useState, useEffect } from 'react';
import { Customer } from '../types';
import { getCustomers, saveCustomer, getUserProfile } from '../services/storageUtils';
import { User, Plus, Search, ChevronRight, Settings } from 'lucide-react';
import Logo from './Logo';

interface Props {
  onSelectCustomer: (id: string) => void;
  onOpenProfile: () => void;
}

const CustomerList: React.FC<Props> = ({ onSelectCustomer, onOpenProfile }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerMobile, setNewCustomerMobile] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [dairyName, setDairyName] = useState('My Dairy');

  useEffect(() => {
    setCustomers(getCustomers());
    const profile = getUserProfile();
    if (profile.dairyName) setDairyName(profile.dairyName);
  }, []);

  const handleAddCustomer = () => {
    if (!newCustomerName) return;
    const newCustomer: Customer = {
      id: Date.now().toString(),
      name: newCustomerName,
      mobile: newCustomerMobile,
      defaultRateType: 'FIX',
    };
    saveCustomer(newCustomer);
    setCustomers(getCustomers());
    setShowAddModal(false);
    setNewCustomerName('');
    setNewCustomerMobile('');
  };

  const filteredCustomers = customers.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.mobile.includes(searchTerm)
  );

  return (
    <div className="h-full relative bg-slate-100 min-h-screen">
      {/* 3D Header */}
      <div className="bg-blue-600 p-6 rounded-b-[30px] shadow-xl sticky top-0 z-10">
        <div className="flex justify-between items-center mb-4">
           <div className="flex items-center gap-3">
              <div className="bg-white p-1 rounded-xl shadow-lg">
                <Logo className="w-10 h-10" />
              </div>
              <div>
                <h1 className="text-2xl font-black text-white tracking-wide uppercase leading-none">
                  DairyBook
                </h1>
                <p className="text-blue-200 text-xs font-medium mt-1 opacity-90">{dairyName}</p>
              </div>
           </div>
           <button 
             onClick={onOpenProfile}
             className="bg-blue-500 p-2 rounded-xl shadow-[0_4px_0_rgb(29,78,216)] border-b-0 active:shadow-none active:translate-y-1 transition-all text-white"
           >
             <Settings className="w-6 h-6" />
           </button>
        </div>

        {/* 3D Search Bar */}
        <div className="relative transform translate-y-2">
          <div className="absolute left-4 top-3.5 text-blue-400">
             <Search className="h-5 w-5" />
          </div>
          <input 
            type="text" 
            placeholder="Search Costmer..." 
            className="w-full pl-12 pr-4 py-3 rounded-xl border-2 border-blue-400/30 bg-blue-800/20 text-white placeholder-blue-200 focus:outline-none focus:bg-blue-700/50 focus:border-white transition-all shadow-inner font-medium"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* List */}
      <div className="px-4 pt-8 pb-28 space-y-4">
        {filteredCustomers.length === 0 ? (
          <div className="text-center text-slate-400 py-10 flex flex-col items-center">
            <div className="bg-slate-200 p-4 rounded-full mb-4">
               <User className="w-8 h-8 opacity-50" />
            </div>
            <p className="font-bold text-lg">No customers found.</p>
            <p className="text-sm">Tap the big + button to add one.</p>
          </div>
        ) : (
          filteredCustomers.map(customer => (
            <div 
              key={customer.id} 
              onClick={() => onSelectCustomer(customer.id)}
              className="bg-white p-4 rounded-2xl shadow-[0_4px_0_rgb(203,213,225)] border-2 border-slate-100 flex items-center justify-between active:scale-[0.98] active:shadow-none active:translate-y-1 transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-100 to-blue-50 border-2 border-blue-100 flex items-center justify-center text-blue-600 font-black text-xl shadow-inner">
                  {customer.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-bold text-slate-700 text-lg group-hover:text-blue-600 transition-colors">{customer.name}</h3>
                  <p className="text-xs font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-md inline-block mt-1">
                    {customer.mobile || "No Mobile"}
                  </p>
                </div>
              </div>
              <div className="bg-slate-50 p-2 rounded-xl text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-colors">
                 <ChevronRight className="h-5 w-5" />
              </div>
            </div>
          ))
        )}
      </div>

      {/* 3D FAB */}
      <button 
        onClick={() => setShowAddModal(true)}
        className="fixed bottom-6 right-6 bg-gradient-to-b from-blue-500 to-blue-600 text-white w-16 h-16 rounded-2xl shadow-[0_8px_20px_rgba(37,99,235,0.4)] border-b-4 border-blue-800 flex items-center justify-center active:border-b-0 active:translate-y-1 transition-all z-20 group"
      >
        <Plus className="h-8 w-8 group-hover:rotate-90 transition-transform duration-300" />
      </button>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fade-in">
          <div className="bg-white rounded-t-[30px] sm:rounded-3xl w-full max-w-sm p-8 shadow-2xl transform transition-all">
            <h2 className="text-2xl font-black mb-6 text-slate-800 flex items-center gap-2">
               <span className="bg-blue-100 p-2 rounded-lg text-blue-600"><User size={20} /></span>
               New Customer
            </h2>
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Name</label>
                <input 
                  type="text" 
                  className="w-full bg-slate-50 border-2 border-slate-200 rounded-xl p-3 focus:border-blue-500 outline-none font-bold text-slate-700 transition-colors"
                  value={newCustomerName}
                  onChange={e => setNewCustomerName(e.target.value)}
                  placeholder="Enter name"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Mobile (Optional)</label>
                <input 
                  type="tel" 
                  className="w-full bg-slate-50 border-2 border-slate-200 rounded-xl p-3 focus:border-blue-500 outline-none font-bold text-slate-700 transition-colors"
                  value={newCustomerMobile}
                  onChange={e => setNewCustomerMobile(e.target.value)}
                  placeholder="Enter mobile number"
                />
              </div>
              <div className="flex gap-4 mt-8">
                <button 
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-3 text-slate-600 font-bold bg-slate-100 rounded-xl hover:bg-slate-200 active:scale-95 transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleAddCustomer}
                  className="flex-1 py-3 text-white font-bold bg-blue-500 rounded-xl shadow-[0_4px_0_rgb(29,78,216)] active:shadow-none active:translate-y-1 hover:bg-blue-600 disabled:opacity-50 disabled:shadow-none disabled:translate-y-1 transition-all"
                  disabled={!newCustomerName}
                >
                  Save Customer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerList;