import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { getUserProfile, saveUserProfile } from '../services/storageUtils';
import { ArrowLeft, Store, User, Phone, Save } from 'lucide-react';
import Logo from './Logo';

interface Props {
  onBack: () => void;
}

const Profile: React.FC<Props> = ({ onBack }) => {
  const [profile, setProfile] = useState<UserProfile>({
    dairyName: '',
    ownerName: '',
    mobile: ''
  });

  useEffect(() => {
    setProfile(getUserProfile());
  }, []);

  const handleSave = () => {
    saveUserProfile(profile);
    alert('Profile Saved Successfully!');
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
       {/* 3D Header */}
      <div className="bg-blue-600 pb-10 pt-6 px-6 rounded-b-[30px] shadow-xl relative z-10">
         <div className="flex items-center gap-3 mb-4">
             <button onClick={onBack} className="bg-blue-500 p-2 rounded-xl shadow-lg border-b-4 border-blue-700 active:border-b-0 active:translate-y-1 transition-all text-white">
                 <ArrowLeft size={24} />
             </button>
             <h1 className="text-2xl font-black text-white tracking-wide">My Profile</h1>
         </div>
         <div className="flex justify-center mb-[-60px]">
             <div className="bg-white p-2 rounded-2xl shadow-[0_10px_20px_rgba(0,0,0,0.2)]">
                <Logo className="w-24 h-24" />
             </div>
         </div>
      </div>

      <div className="mt-20 px-6 space-y-6">
        <div className="bg-white p-6 rounded-2xl shadow-[0_8px_0_rgb(226,232,240)] border-2 border-slate-100">
           <div className="space-y-4">
               
               <div>
                   <label className="text-slate-500 font-bold text-xs uppercase tracking-wider mb-2 block">Dairy Name</label>
                   <div className="flex items-center bg-slate-50 rounded-xl p-3 border-2 border-slate-200 focus-within:border-blue-400 transition-colors">
                       <Store className="text-slate-400 mr-3" />
                       <input 
                         type="text"
                         value={profile.dairyName}
                         onChange={e => setProfile({...profile, dairyName: e.target.value})}
                         className="bg-transparent w-full outline-none font-bold text-slate-700"
                         placeholder="Enter Dairy Name"
                       />
                   </div>
               </div>

               <div>
                   <label className="text-slate-500 font-bold text-xs uppercase tracking-wider mb-2 block">Owner Name</label>
                   <div className="flex items-center bg-slate-50 rounded-xl p-3 border-2 border-slate-200 focus-within:border-blue-400 transition-colors">
                       <User className="text-slate-400 mr-3" />
                       <input 
                         type="text"
                         value={profile.ownerName}
                         onChange={e => setProfile({...profile, ownerName: e.target.value})}
                         className="bg-transparent w-full outline-none font-bold text-slate-700"
                         placeholder="Your Name"
                       />
                   </div>
               </div>

               <div>
                   <label className="text-slate-500 font-bold text-xs uppercase tracking-wider mb-2 block">Mobile Number</label>
                   <div className="flex items-center bg-slate-50 rounded-xl p-3 border-2 border-slate-200 focus-within:border-blue-400 transition-colors">
                       <Phone className="text-slate-400 mr-3" />
                       <input 
                         type="text"
                         value={profile.mobile}
                         onChange={e => setProfile({...profile, mobile: e.target.value})}
                         className="bg-transparent w-full outline-none font-bold text-slate-700"
                         placeholder="+91 00000 00000"
                       />
                   </div>
               </div>

           </div>
        </div>

        <button 
            onClick={handleSave}
            className="w-full bg-blue-500 text-white font-black text-lg py-4 rounded-2xl shadow-[0_6px_0_rgb(29,78,216)] active:shadow-none active:translate-y-1.5 transition-all flex items-center justify-center gap-2"
        >
            <Save /> SAVE PROFILE
        </button>
      </div>
    </div>
  );
};

export default Profile;