import React, { useState } from 'react';
import CustomerList from './components/CustomerList';
import CustomerDetail from './components/CustomerDetail';
import Profile from './components/Profile';
import { AppState } from './types';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    view: 'HOME',
    selectedCustomerId: null
  });

  const handleSelectCustomer = (id: string) => {
    setState({
      view: 'CUSTOMER_DETAIL',
      selectedCustomerId: id
    });
  };

  const handleOpenProfile = () => {
    setState({
      ...state,
      view: 'PROFILE'
    });
  };

  const handleBack = () => {
    setState({
      view: 'HOME',
      selectedCustomerId: null
    });
  };

  return (
    <div className="max-w-md mx-auto h-screen bg-white shadow-2xl overflow-hidden relative">
      {state.view === 'HOME' && (
        <CustomerList 
            onSelectCustomer={handleSelectCustomer} 
            onOpenProfile={handleOpenProfile}
        />
      )}

      {state.view === 'CUSTOMER_DETAIL' && state.selectedCustomerId && (
        <CustomerDetail 
          customerId={state.selectedCustomerId} 
          onBack={handleBack} 
        />
      )}

      {state.view === 'PROFILE' && (
        <Profile onBack={handleBack} />
      )}
    </div>
  );
};

export default App;