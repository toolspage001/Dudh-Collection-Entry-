import { GoogleGenAI } from "@google/genai";
import { Entry, Customer } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeCustomerData = async (customer: Customer, entries: Entry[]) => {
  if (!process.env.API_KEY) {
    return "API Key not configured. Unable to generate insights.";
  }

  // Prepare data summary for the prompt
  const recentEntries = entries.slice(-30); // Last 30 entries
  const totalMilk = recentEntries.reduce((sum, e) => sum + e.weight, 0).toFixed(2);
  const totalMoney = recentEntries.reduce((sum, e) => sum + e.totalAmount, 0).toFixed(2);
  const avgFat = (recentEntries.reduce((sum, e) => sum + (e.fat || 0), 0) / (recentEntries.filter(e => e.fat).length || 1)).toFixed(2);

  const prompt = `
    Analyze the milk collection data for customer: ${customer.name}.
    Data Summary (Last 30 entries):
    - Total Milk: ${totalMilk} Liters
    - Total Earnings: ₹${totalMoney}
    - Average Fat: ${avgFat} (if applicable)
    
    Provide a short, encouraging summary in Hinglish (Hindi + English) about their performance. 
    Point out if their milk quantity is increasing or decreasing.
    Keep it under 3 sentences. Professional tone.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Could not analyze data at the moment.";
  }
};
