import { Customer, Entry, UserProfile } from '../types';

const KEYS = {
  CUSTOMERS: 'dairybook_customers',
  ENTRIES: 'dairybook_entries',
  PROFILE: 'dairybook_profile',
};

export const getCustomers = (): Customer[] => {
  const data = localStorage.getItem(KEYS.CUSTOMERS);
  return data ? JSON.parse(data) : [];
};

export const saveCustomer = (customer: Customer): void => {
  const customers = getCustomers();
  customers.push(customer);
  localStorage.setItem(KEYS.CUSTOMERS, JSON.stringify(customers));
};

export const getEntries = (customerId?: string): Entry[] => {
  const data = localStorage.getItem(KEYS.ENTRIES);
  const entries: Entry[] = data ? JSON.parse(data) : [];
  if (customerId) {
    return entries.filter(e => e.customerId === customerId);
  }
  return entries;
};

export const saveEntry = (entry: Entry): void => {
  const entries = getEntries();
  entries.push(entry);
  localStorage.setItem(KEYS.ENTRIES, JSON.stringify(entries));
};

export const deleteEntry = (entryId: string): void => {
    let entries = getEntries();
    entries = entries.filter(e => e.id !== entryId);
    localStorage.setItem(KEYS.ENTRIES, JSON.stringify(entries));
}

export const getUserProfile = (): UserProfile => {
  const data = localStorage.getItem(KEYS.PROFILE);
  return data ? JSON.parse(data) : { dairyName: 'My Dairy Farm', ownerName: '', mobile: '' };
};

export const saveUserProfile = (profile: UserProfile): void => {
  localStorage.setItem(KEYS.PROFILE, JSON.stringify(profile));
};